import 'package:flutter/material.dart';
import 'package:easy_refresh/easy_refresh.dart';
import 'package:provider/provider.dart';
import '../providers/member_provider.dart';

class MembersScreen extends StatefulWidget {
  const MembersScreen({super.key});

  @override
  State<MembersScreen> createState() => _MembersScreenState();
}

class _MembersScreenState extends State<MembersScreen> {
  final List<dynamic> _members = [];
  int _currentPage = 1;
  final int _pageSize = 10;
  bool _hasMore = true;
  bool _isLoading = false;

  final EasyRefreshController _controller = EasyRefreshController();
  final ScrollController _scrollController = ScrollController();

  // filters
  String? _selectedGender;
  String? _selectedCity;
  RangeValues _ageRange = const RangeValues(18, 65);

  @override
 @override
void initState() {
  super.initState();
  _loadMembers(reset: true);

  _scrollController.addListener(() {
    // When user scrolls near the top (in reversed list = older page)
    if (_scrollController.position.pixels >=
            _scrollController.position.maxScrollExtent - 100 &&
        !_isLoading &&
        _hasMore) {
      _loadMoreOlderMembers();
    }
  });
}

Future<void> _loadMoreOlderMembers() async {
  if (_isLoading) return;
  _isLoading = true;

  try {
    final provider = Provider.of<MemberProvider>(context, listen: false);
    final newMembers = await provider.fetchMembersPage(
      page: _currentPage + 1,
      gender: _selectedGender,
      city: _selectedCity,
      ageRange: _ageRange,
    );

    if (newMembers.isEmpty) {
      _hasMore = false;
    } else {
      setState(() {
        _currentPage++;
        _members.insertAll(0, newMembers); // Prepend older members
      });

      // Maintain scroll offset so the view doesn’t jump
      await Future.delayed(Duration(milliseconds: 100));
      _scrollController.jumpTo(
        _scrollController.position.pixels + 200,
      );
    }
  } catch (e) {
    print("Error loading older members: $e");
  } finally {
    _isLoading = false;
  }
}

Future<void> _loadMembers({bool reset = false}) async {
  if (_isLoading) return;
  _isLoading = true;

  if (reset) {
    _currentPage = 1;
    _members.clear();
    _hasMore = true;
  }

  try {
    final provider = Provider.of<MemberProvider>(context, listen: false);
    final newMembers = await provider.fetchMembersPage(
      page: _currentPage,
      gender: _selectedGender,
      city: _selectedCity,
      ageRange: _ageRange,
    );

    setState(() {
      _members.addAll(newMembers); // Add page 1 at bottom (reversed view)
      if (newMembers.isEmpty) _hasMore = false;
    });
  } catch (e) {
    print("Error loading members: $e");
  } finally {
    _isLoading = false;
  }
}


  void _onSearchPressed() {
    FocusScope.of(context).unfocus(); // Hide keyboard
    _loadMembers(reset: true); // ✅ Refresh list with new filters
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Members')),
      body: Column(
        children: [
          // 🔍 Search Filter Section
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                // Gender & City
                Row(
                  children: [
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        decoration: const InputDecoration(labelText: 'Gender'),
                        value: _selectedGender,
                        onChanged: (v) => setState(() => _selectedGender = v),
                        items: const [
                          DropdownMenuItem(value: '', child: Text('Any')),
                          DropdownMenuItem(value: 'm', child: Text('Male')),
                          DropdownMenuItem(value: 'f', child: Text('Female')),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextFormField(
                        decoration: const InputDecoration(labelText: 'City'),
                        onChanged: (v) => _selectedCity = v,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                // Age Range
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Age Range: ${_ageRange.start.toInt()} - ${_ageRange.end.toInt()}"),
                    RangeSlider(
                      values: _ageRange,
                      min: 18,
                      max: 65,
                      divisions: 47,
                      labels: RangeLabels(
                        _ageRange.start.toInt().toString(),
                        _ageRange.end.toInt().toString(),
                      ),
                      onChanged: (v) => setState(() => _ageRange = v),
                    ),
                  ],
                ),
                ElevatedButton.icon(
                  onPressed: _onSearchPressed,
                  icon: const Icon(Icons.search),
                  label: const Text('Search'),
                ),
              ],
            ),
          ),
          const Divider(height: 1),

          // 🔄 Member List
          Expanded(
            child: EasyRefresh(
              controller: _controller,
              header: const ClassicHeader(),
              footer: const ClassicFooter(),
              onRefresh: () async => _loadMembers(reset: true),
              onLoad: _hasMore ? () async => _loadMembers() : null,
              child: ListView.builder(
                controller: _scrollController,
                itemCount: _members.length,
                 reverse: true, // Important!
                itemBuilder: (context, index) {
                  final member = _members[index];
                  final basic = member['basic_info'] ?? {};

                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                    child: ListTile(
                      leading: CircleAvatar(
                             backgroundImage: NetworkImage(
                          (member['image'] != null &&
                                  member['image'].toString().isNotEmpty)
                              ? 'https://staging.sahakaru.com/assets/images/user/profile/${member['image']}'
                              : 'https://via.placeholder.com/150',
                        ),

                      ),
                      title: Text("${member['firstname'] ?? 'Unknown'}"),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Profile ID: ${member['profile_id'] ?? 'N/A'} | Religion: ${basic['religion'] ?? 'N/A'}",
                          ),
                          Text(
                            "Gender: ${basic['gender'] == 'm' ? 'Male' : basic['gender'] == 'f' ? 'Female' : 'N/A'} | Profession: ${basic['profession'] ?? 'N/A'}",
                          ),
                          Text(
                            "City: ${basic['present_address']?['city'] ?? 'N/A'} | Birth date: ${basic['birth_date'] ?? 'N/A'}",
                          ),
                        ],
                      ),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
